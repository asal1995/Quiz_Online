from django.contrib import admin

from quiz_app.models import Answer, Qusetion, Result, User, cattegory

admin.site.register(User)
admin.site.register(cattegory)
admin.site.register(Qusetion)
admin.site.register(Answer)
admin.site.register(Result)
