
from django.contrib import admin
from django.urls import path
from .views import Creat_User, Exam_Correction, get_quiiz

urlpatterns = [

    path('gq/',get_quiiz ,name='create_quiz'),
    path('ec/',Exam_Correction ,name='examcr'),
    path('cu/<str:user_id>',Creat_User ,name='createuser'),
    
]
