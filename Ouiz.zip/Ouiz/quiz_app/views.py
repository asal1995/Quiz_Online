from django.views.decorators.csrf import csrf_exempt
from django.http.response import JsonResponse
import json
from .models import Result, User, cattegory
import random

f_score=list()
current=None

@csrf_exempt
def Creat_User(request):
    # current_id.clear()
    if request.method=='POST':
        data=json.loads(request.body)
        if 'username' not in data or 'password' not in data or 'id' not in data:
            return JsonResponse({'status':'error','msg':'Enter username ,password, id'},status=403)
        username=data.get('username','')
        password=data.get('password','')
        user_id=data.get('id', '')
        current=User.objects.create(username=username, passw=password, user_id=user_id)
        # current_id.append(current_user.id)
        return JsonResponse({'status':'successfull','msg':'user created.'},status=201)
    else:
        return JsonResponse({'status':'error','msg':'method must be post'},status=403)



quiz_l= []
correct=[]


def get_quiiz(request):
    correct.clear()
    quiz_l.clear()
    quiz={}
    cat = cattegory.objects.all()
    for c in cat:
        quiz[c.cat_name] = {}
        question = list(c.question.all())
        rq = random.sample(question, 3)
        for q in rq:
            ans = list(q.answer.values_list('title',flat=True))
            quiz[c.cat_name][q.quest_title] = ans
            correct.append(q.correct_ans)
   
    quiz_l.append(quiz)
    return JsonResponse({"quiz": quiz})

myscore=0     


@csrf_exempt
def Exam_Correction(request, user_id):
    score=0
    f_score.clear()
    if request.method=='POST':
        
        data=json.loads(request.body)
        user_answer=list()
        for i in data:
            user_answer.append(data.get(i))

        for i,j in zip(correct,user_answer):
            if i==j:
                score+=1
        myscore=score
        f_score.append(score)
    user = User.objects.get(usrid=user_id)
    Result.objects.create(score=myscore,quiz_history=quiz_l, user=user)
    return JsonResponse({'correct answer': correct , 'your score:':f_score,"userans":user_answer})
    









            


        