from typing import Counter, Iterable, Optional
from django.db import models




class User(models.Model):
    username=models.CharField(max_length=250, unique=True)
    passw=models.CharField(max_length=250)
    user_id=models.IntegerField(primary_key=True)


    def __str__(self) -> str:
        return self.username


class cattegory(models.Model):
    cat_name=models.CharField(max_length=40)
    cat_id=models.IntegerField(primary_key=True)


    def __str__(self) -> str:
        return self.cat_name 



class Qusetion(models.Model):
    correct_ans_ch=[
        ('a','a'),
        ('b','b'),
        ('c','c'),
        ('d','d'),
    ]
    quest_title=models.TextField()
    cat_id=models.ForeignKey(cattegory , on_delete=models.CASCADE,related_name='question')
    correct_ans=models.CharField(max_length=5,null=True,choices=correct_ans_ch)

   


    def __str__(self) -> str:
        return self.quest_title


class Answer(models.Model):
    ans_choice=[
        ('a','a'),
        ('b','b'),
        ('c','c'),
        ('d','d')
    ]

    title=models.CharField(max_length=250)
    quest_id=models.ForeignKey(Qusetion , on_delete=models.RESTRICT,related_name='answer')
    answer_a=models.CharField(max_length=5 ,null=True,choices=ans_choice)
     
    # def save(self, *args, **kwargs)-> None:
    #    
    #     return super().save(self, *args, **kwargs))

    def __str__(self) -> str:
        return self.title

        

class Result(models.Model):
    
    score=models.IntegerField()
    date=models.DateField(auto_now_add=True)
    user_id=models.ForeignKey(User ,on_delete=models.CASCADE , related_name='result')
    quiz_history=models.JSONField(null=True)
    
    def __str__(self) -> str:
        return self.score


    






